// app.js

const express = require('express');
const connectDB = require('./config/db')
const bookRouter = require('./routes/api/book.js')




const app = express();
app.use(express.json({ limit: "50mb", extended: true }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

connectDB();



app.get('/', (req, res) => res.send('Hello world!'));
app.use('/books',bookRouter);

const port = process.env.PORT || 8082;

app.listen(port, () => console.log(`Server running on port ${port}`));