// routes /api/book.js
const express = require('express');
const router = express.Router();

const Book = require('../../models/Book.js');

// @route GET api/books/test
router.get('/test',(req,res)=> res.send('book route testing!'));

// @route GET api/books gets all books

router.get('/',(req,res)=>{
    Book.find().then(books => res.json(books)).catch(err => res.status(404).json({nobooksfound:'no books found'}))
});

router.get('/:id',(req,res)=>{
    Book.findById(req.params.id).then(books => res.json(books)).catch(err => res.status(404).json({nobooksfound:'no books found'}))
});

router.post('/',async(req,res)=>{
    console.log(req.body);
    const { title , isbn , author , description, publisher } = req.body; 
    try{
       const result = await Book.create({title,isbn,author,description,publisher});
       res.status(200);
       res.json({msg: "Book published",result});
    }catch(error){
       res.status(404);
       res.json({msg:"NOthing"});
    }
    //Book.create(req.body).then(books => res.json({msg : "Book added successfully"})).catch(err => res.status(404).json({nobooksfound:'unable'}))
});

router.put('/:id',(req,res)=>{
    Book.findByIdAndUpdate(req.params.id, req.body)
    .then(book => res.json({ msg: 'Updated successfully' }))
    .catch(err =>
      res.status(400).json({ error: 'Unable to update the Database' })
    );
});
router.delete('/:id', (req, res) => {
    Book.findByIdAndRemove(req.params.id, req.body)
      .then(book => res.json({ mgs: 'Book entry deleted successfully' }))
      .catch(err => res.status(404).json({ error: 'No such a book' }));
  });

module.exports = router